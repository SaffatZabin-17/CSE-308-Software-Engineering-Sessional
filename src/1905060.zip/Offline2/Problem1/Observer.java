package Offline2.Problem1;

public interface Observer {
    void update();
}
